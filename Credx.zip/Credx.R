# We have to install below packages if not installed.
library(MASS)
library(car)
library(caret)
library(ggplot2)
library(Hmisc)
library(ggthemes)
library(ROCR)
library(grid)
library(dplyr)
library(scales)
library(ggcorrplot)
library(gridExtra)
library(data.table)
library(tidyr)
library(broom)
library(cowplot)
library(caTools)
library(e1071)
library(randomForest)
library(DMwR)
library(scorecard)
library(corrplot)
library(lift)
library(woe)
library(woeBinning)
library(Information)
library(ROSE)
library(readr)
library(kernlab)
library(plyr)

## Set the working directory to the path of data set.

# Importing Demographic and Credit data into R. The "NA" string values from the CSV is imported as NA using na.strings#
# Columns names are modified to short names.

demographic<-read.csv("Demographic data.csv",na.strings = c("NA",""," "),stringsAsFactors = F, 
                      col.names = c("Application_ID",                            
                                    "Age"           ,                            
                                    "Gender"         ,                            
                                    "Marital_Status",
                                    "No_of_dependents",                          
                                    "Income"          ,                           
                                    "Education"        ,                          
                                    "Profession"        ,                         
                                    "Type_of_residence"  ,                        
                                    "No_of_months_in_current_residence" ,         
                                    "No_of_months_in_current_company"    ,        
                                    "Performance_Tag"))
credit_beareau<-read.csv("Credit Bureau data.csv",na.strings = c("NA",""," "),stringsAsFactors = F,
                         col.names = c("Application_ID"  ,                                               
                                       "No_of_times_90_DPD_or_worse_6_months"   ,                
                                       "No_of_times_60_DPD_or_worse_6_months"   ,                
                                       "No_of_times_30_DPD_or_worse_6_months"  ,                 
                                       "No_of_times_90_DPD_or_worse_12_months" ,                 
                                       "No_of_times_60_DPD_or_worse_12_months" ,                 
                                       "No_of_times_30_DPD_or_worse_12_months" ,                 
                                       "Avgas_CC_Utilization_in_12_months"  ,                       
                                       "trades_opened_in_last_6_months"   ,                        
                                       "trades_opened_in_last_12_months"  ,                        
                                       "PL_trades_opened_in_last_6_months"   ,                     
                                       "PL_trades_opened_in_last_12_months"  ,                     
                                       "Inquiries_in_last_6_months_exc_home_auto_loans" ,
                                       "Inquiries_in_last_12_months_exc_home_auto_loans",
                                       "Has_open_home_loan"  ,                                   
                                       "Outstanding_Balance" ,                                           
                                       "Total_No_of_Trades"  ,                                           
                                       "Has_open_auto_loan"  ,                                   
                                       "Performance_Tag"))

# Understanding the Data & Removing the duplicate rows in both Demographic & Credit Bureau data#

#Lets see the structure of the given data#

str(demographic)
str(credit_beareau)

# Glimpse on data
head(demographic)
head(credit_beareau)

#Observations and variables
dim(demographic)
# 71295 obs  12 variables.
dim(credit_beareau)
# 71295 obs 19 variables.



length(unique(tolower(demographic$Application_ID)))

# [1] 71292

length(unique(tolower(credit_beareau$Application_ID)))
# [1] 71292

sum(duplicated(demographic$Application_ID))
# There are 3 duplicates.
duplicated(credit_beareau$Application_ID)

sum(duplicated(credit_beareau$Application_ID))
# There are 3 duplicates.

# As the number of duplicate records are minimal. Lets remove them from both the data sets.

## Duplicate records
demographic[which(duplicated(demographic$Application_ID) == T), 1]
#[1] 765011468 653287861 671989187#

credit_beareau[which(duplicated(credit_beareau$Application_ID) == T), 1]
#[1] 765011468 653287861 671989187

## Removing the dupicates from the data set.

demographic <- demographic[-which(duplicated(demographic$Application_ID) == T), ]

credit_beareau <- credit_beareau[-which(duplicated(credit_beareau$Application_ID) == T), ]

# Lets merge the data into master_data. Lets do full outer join

master_data <- merge(demographic,credit_beareau,by=c("Application_ID","Performance_Tag"),all = T)

length(demographic$Application_ID) #71292
length(credit_beareau$Application_ID) #71292
length(master_data$Application_ID) #71292

# As the total number of observations before merging and after merging is same we can confirm that there is no data loss.

#Lets see the missing values
sum(is.na(master_data))

sapply(master_data,function(x) sum(is.na(x))) # Gives Missing data in each variable



#Application_ID 0 
#Performance_Tag 1425 
#Age 0 
#Gender 2 
#Marital_Status 6 
#No_of_dependents 3 
#Income 0 
#Education 119 
#Profession 14 
#Type_of_residence 8 
#No_of_months_in_current_residence 0 
#No_of_months_in_current_company 0 
#No_of_times_90_DPD_or_worse_6_months 0 
#No_of_times_60_DPD_or_worse_6_months 0 
#No_of_times_30_DPD_or_worse_6_months 0 
#No_of_times_90_DPD_or_worse_12_months 0 
#No_of_times_60_DPD_or_worse_12_months 0 
#No_of_times_30_DPD_or_worse_12_months 0 
#Avgas_CC_Utilization_in_12_months 1058 
#trades_opened_in_last_6_months 1 
#trades_opened_in_last_12_months 0 
#PL_trades_opened_in_last_6_months 0 
#PL_trades_opened_in_last_12_months 0 
#Inquiries_in_last_6_months_exc_home_auto_loans 0 
#Inquiries_in_last_12_months_exc_home_auto_loans 0 
#Has_open_home_loan 272 
#Outstanding_Balance 272 
#Total_No_of_Trades 0 
#Has_open_auto_loan 0 


#We are not going to impute values for missing data as WOE will take care of missing values.

###EDA of the given data begins here######

##Functions for plotting univariate graphs

#1.Categorical
Fn1 <- function(dataset,var,x_label){
  
  dataset %>% ggplot(aes(x = as.factor(var), fill = as.factor(var))) +
    
    geom_bar(aes(y = (..count..)/sum(..count..))) +
    
    geom_text(aes(y = ((..count..)/sum(..count..)), label = scales::percent((..count..)/sum(..count..))), stat = "count", vjust = -0.25) +
    
    scale_y_continuous(labels = scales::percent) +
    
    labs(title =  "Fequency Distribution", y = "Percentage", x = x_label)+theme(
      
      axis.text.y=element_blank(), axis.ticks=element_blank(),
      
      axis.title.y=element_blank(),axis.text.x = element_text(angle = 30, hjust = 0.5)
      
    ) 
  
}


#2.Continuous variable
Fn2 <- function(dataset,var,x_label){
  
  dataset %>% ggplot(aes(x = (var))) +
    
    geom_histogram(breaks=seq(min(var), max(var), by=1),col="green", aes(fill=..count..)) +
    
    scale_fill_gradient("Count", low="yellow", high=" dark green")+
    
    labs(title = "Frequency Distribution", y = "Count", x = x_label)
}

### Univariate Analysis and outlier treatment ###

##1.Age
describe(master_data$Age)

# Invalid values are there like -3, 0 etc lets replace those values with 21. Because most people will start their career at 21.

master_data$Age[master_data$Age < 21 ] <- 21

Fn2(master_data,master_data$Age,"Age")

#We can see high density between 35 and 55 Age. 

##2.Gender
describe(master_data$Gender) 
# 2 missing values are there in Gender. Lets handle it by WOE

#Value          F     M
#Frequency  16837 54453
#Proportion 0.236 0.764

Fn1(master_data,master_data$Gender,"Gender")

##3.Marital_Status
describe(master_data$Marital_Status)
# 6 missing values are there. Lets handle it by WOE

#Value      Married  Single
#Frequency    60727   10559
#Proportion   0.852   0.148

Fn1(master_data,master_data$Marital_Status,"Marital_Status")

##4.No_of_dependents
describe(master_data$No_of_dependents) 
# 3 missing values

#Value          1     2     3     4     5
#Frequency  15387 15289 16279 12220 12114
#Proportion 0.216 0.214 0.228 0.171 0.170

Fn1(master_data,master_data$No_of_dependents,"Dependents")

##5.Income
describe(master_data$Income) 
#Values like -0.5 and 0.0 are present. Lets replace them with 1.0

master_data$Income[master_data$Income < 1.0 ] <- 1.0

Fn2(master_data,master_data$Income,"Income")

# No of People with Income around 5$ seems to apply more for credit card

##6.Education
describe(master_data$Education)
# Missing value: 119

#Value          Bachelor      Masters       Others          Phd Professional
#Frequency         17697        23970          121         4548        24837
#Proportion        0.249        0.337        0.002        0.064        0.349
Fn1(master_data,master_data$Education,"Education")

##7.Profession
describe(master_data$Profession)
#Missing value: 14

#Value          SAL      SE SE_PROF
#Frequency    40438   14305   16535
#Proportion   0.567   0.201   0.232
Fn1(master_data,master_data$Profession,"Profession")

##8.Type_of_residence
describe(master_data$Type_of_residence)
#Missing value: 8

#Value         Company provided Living with Parents              Others              Owned              Rented
#Frequency                 1630                1818                 199              14243               53394
#Proportion               0.023               0.026               0.003              0.200               0.749
Fn1(master_data,master_data$Type_of_residence,"Type_of_residence")
# 74.9% stays in rented house

##9.No_of_months_in_current_residence
describe(master_data$No_of_months_in_current_residence)

Fn2(master_data,master_data$No_of_months_in_current_residence,"No_of_months_in_current_residence")
# Most of the applicants stays in the house for past 6 months

##10.No_of_months_in_current_company
describe(master_data$No_of_months_in_current_company)

Fn2(master_data,master_data$No_of_months_in_current_company,"No_of_months_in_current_company")
# Most of the applicant is less than a year in the current company

##11.No_of_times_90_DPD_or_worse_6_months
describe(master_data$No_of_times_90_DPD_or_worse_6_months) 

#Value          0     1     2     3
#Frequency  54867 13873  2258   294
#Proportion 0.770 0.195 0.032 0.004

Fn1(master_data,master_data$No_of_times_90_DPD_or_worse_6_months,"No_of_times_90_DPD_or_worse_6_months")

##12.No_of_times_60_DPD_or_worse_6_months
describe(master_data$No_of_times_60_DPD_or_worse_6_months)

#Value          0     1     2     3     4     5
#Frequency  51922 11393  5412  1876   597    92
#Proportion 0.728 0.160 0.076 0.026 0.008 0.001

Fn1(master_data,master_data$No_of_times_60_DPD_or_worse_6_months,"No_of_times_60_DPD_or_worse_6_months")


##13.No_of_times_30_DPD_or_worse_6_months
describe(master_data$No_of_times_30_DPD_or_worse_6_months)

#Value          0     1     2     3     4     5     6     7
#Frequency  50108  9609  6194  3269  1389   565   142    16
#Proportion 0.703 0.135 0.087 0.046 0.019 0.008 0.002 0.000

Fn1(master_data,master_data$No_of_times_30_DPD_or_worse_6_months,"No_of_times_30_DPD_or_worse_6_months")

##14.No_of_times_90_DPD_or_worse_12_months
describe(master_data$No_of_times_90_DPD_or_worse_12_months)

#Value          0     1     2     3     4     5
#Frequency  50539 11991  6654  1672   390    46
#Proportion 0.709 0.168 0.093 0.023 0.005 0.001

Fn1(master_data,master_data$No_of_times_90_DPD_or_worse_12_months,"No_of_times_90_DPD_or_worse_12_months")

##15.No_of_times_60_DPD_or_worse_12_months
describe(master_data$No_of_times_60_DPD_or_worse_12_months) 

#Value          0     1     2     3     4     5     6     7
#Frequency  45880 12927  6695  3643  1420   569   148    10
#Proportion 0.644 0.181 0.094 0.051 0.020 0.008 0.002 0.000

Fn1(master_data,master_data$No_of_times_60_DPD_or_worse_12_months,"No_of_times_60_DPD_or_worse_12_months")

##16.No_of_times_30_DPD_or_worse_12_months
describe(master_data$No_of_times_30_DPD_or_worse_12_months)

#Value          0     1     2     3     4     5     6     7     8     9
#Frequency  44862 11502  6265  4450  2309  1166   549   160    27     2
#Proportion 0.629 0.161 0.088 0.062 0.032 0.016 0.008 0.002 0.000 0.000

Fn1(master_data,master_data$No_of_times_30_DPD_or_worse_12_months,"No_of_times_30_DPD_or_worse_12_months")

##17.Avgas_CC_Utilization_in_12_months
describe(master_data$Avgas_CC_Utilization_in_12_months)

# Missing values: 1058. Lets Impute 0 for Na values. 
#Because in the problem statement it is mentioned if the applicant doesnt have any credit card this field will be NA

master_data$Avgas_CC_Utilization_in_12_months[which(is.na(master_data$Avgas_CC_Utilization_in_12_months))] <- 0

Fn2(master_data,master_data$Avgas_CC_Utilization_in_12_months,"Avgas_CC_Utilization_in_12_months")

##18.trades_opened_in_last_6_months
describe(master_data$trades_opened_in_last_6_months)

#Missing value: 1
#Value          0     1     2     3     4     5     6     7     8     9    10    11    12
#Frequency  12231 20250 12461  9850  6624  3791  2349  1649  1154   618   238    65    11
#Proportion 0.172 0.284 0.175 0.138 0.093 0.053 0.033 0.023 0.016 0.009 0.003 0.001 0.000

Fn1(master_data,master_data$trades_opened_in_last_6_months,"trades_opened_in_last_6_months")

##19.trades_opened_in_last_12_months
describe(master_data$trades_opened_in_last_12_months)

Fn2(master_data,master_data$trades_opened_in_last_12_months,"trades_opened_in_last_12_months")

##20.PL_trades_opened_in_last_6_months
describe(master_data$PL_trades_opened_in_last_6_months)
#Value          0     1     2     3     4     5     6
#Frequency  31193 13852 13079  8320  3462  1090   296
#Proportion 0.438 0.194 0.183 0.117 0.049 0.015 0.004

Fn1(master_data,master_data$PL_trades_opened_in_last_6_months,"PL_trades_opened_in_last_6_months")


#21.PL_trades_opened_in_last_12_months
describe(master_data$PL_trades_opened_in_last_12_months)

#Value          0     1     2     3     4     5     6     7     8     9    10    11    12
#Frequency  25828  6693  6982  8432  8272  6485  4206  2284  1178   601   255    66    10
#Proportion 0.362 0.094 0.098 0.118 0.116 0.091 0.059 0.032 0.017 0.008 0.004 0.001 0.000

Fn1(master_data,master_data$PL_trades_opened_in_last_12_months,"PL_trades_opened_in_last_12_months")

##22.Inquiries_in_last_6_months_exc_home_auto_loans
describe(master_data$Inquiries_in_last_6_months_exc_home_auto_loans) 
#Value          0     1     2     3     4     5     6     7     8     9    10
#Frequency  25176 13511 13349  7585  4385  3019  1750  1149   835   425   108
#Proportion 0.353 0.190 0.187 0.106 0.062 0.042 0.025 0.016 0.012 0.006 0.002

Fn1(master_data,master_data$Inquiries_in_last_6_months_exc_home_auto_loans,"Inquiries_in_last_6_months_exc_home_auto_loans")

##23.Inquiries_in_last_12_months_exc_home_auto_loans
describe(master_data$Inquiries_in_last_12_months_exc_home_auto_loans)

Fn2(master_data,master_data$Inquiries_in_last_12_months_exc_home_auto_loans,"Inquiries_in_last_12_months_exc_home_auto_loans")

##24.Has_open_home_loan
describe(master_data$Has_open_home_loan)
#Missing Values: 272

Fn1(master_data,master_data$Has_open_home_loan,"Has_open_home_loan")

#25.Outstanding_Balance
describe(master_data$Outstanding_Balance)
#Missing Values: 272. Lets remove these NA as these are minimal

master_data <- master_data[-which(is.na(master_data$Outstanding_Balance)),]

##26.Total_No_of_Trades
describe(master_data$Total_No_of_Trades) 

Fn2(master_data,master_data$Total_No_of_Trades,"Total_No_of_Trades")

##27.Has_open_auto_loan
describe(master_data$Has_open_auto_loan) 

Fn1(master_data,master_data$Has_open_auto_loan,"Has_open_auto_loan")

##28.Has_open_auto_loan
describe(master_data$Has_open_auto_loan) 

Fn1(master_data,master_data$Has_open_auto_loan,"Has_open_auto_loan")

##29.Has_open_auto_loan
describe(master_data$Performance_Tag) 

Fn1(master_data,master_data$Performance_Tag,"Performance_Tag")

#We have 1425 values missing for the dependent variable Performance_Tag.
#Lets put this 1425 records in a different dataframe named Rejected_data.
#These are the applicants for whom credit cards were rejected.
#Lets predict Performance_Tag for these records with the model that we are going to build.

#Moving the dependant variable Performance_Tag to last

master_data <- master_data %>% select(-Performance_Tag,Performance_Tag)

# Seperating Approved Applicants and Rejected applicants in two dataframe

Rejected_data <- master_data[which(is.na(master_data$Performance_Tag)),]

master_data <- master_data[-which(is.na(master_data$Performance_Tag)),]

###Bi-Variate Analysis ###

# Lets see the relation of each variable with the dependant variable

plot_performance <- function(df,cat_var, var_name){
  a <- aggregate(Performance_Tag~cat_var, df, mean)
  count <- data.frame(table(cat_var))
  count <- count[,-1]
  agg_performance <- cbind(a, count)
  
  colnames(agg_performance) <- c(var_name, "Default","No.of_Applicants")
  agg_performance[, 2] <- format(round(agg_performance[, 2], 2))
  
  ggplot(agg_performance, aes(agg_performance[, 1], No.of_Applicants, label = Default, fill = "red")) + geom_bar(stat = 'identity') + theme(axis.text.x = element_text(angle = 60, hjust = 1)) + geom_text(size = 3, vjust = -0.5) + xlab(var_name)+
  ggtitle("Default rate")+theme(plot.title = element_text(hjust = 0.5))
}

plot_performance(master_data,master_data$Age, "Age")
plot_performance(master_data,master_data$Gender, "Gender")
plot_performance(master_data,master_data$Marital_Status,"Marital_Status")
plot_performance(master_data,master_data$No_of_dependents,"No_of_dependents") 
plot_performance(master_data,master_data$Income,"Income") 
plot_performance(master_data,master_data$Education,"Education") 
plot_performance(master_data,master_data$Profession,"Profession") 
plot_performance(master_data,master_data$Type_of_residence,"Type_of_residence") 
plot_performance(master_data,master_data$No_of_months_in_current_residence,"No_of_months_in_current_residence") 
plot_performance(master_data,master_data$No_of_months_in_current_company,"No_of_months_in_current_company") 
plot_performance(master_data,master_data$No_of_times_90_DPD_or_worse_6_months,"No_of_times_90_DPD_or_worse_6_months") 
plot_performance(master_data,master_data$No_of_times_60_DPD_or_worse_6_months,"No_of_times_60_DPD_or_worse_6_months") 
plot_performance(master_data,master_data$No_of_times_30_DPD_or_worse_6_months,"No_of_times_30_DPD_or_worse_6_months") 
plot_performance(master_data,master_data$No_of_times_90_DPD_or_worse_12_months,"No_of_times_90_DPD_or_worse_12_months") 
plot_performance(master_data,master_data$No_of_times_60_DPD_or_worse_12_months,"No_of_times_60_DPD_or_worse_12_months") 
plot_performance(master_data,master_data$No_of_times_30_DPD_or_worse_12_months,"No_of_times_30_DPD_or_worse_12_months") 
plot_performance(master_data,master_data$Avgas_CC_Utilization_in_12_months,"Avgas_CC_Utilization_in_12_months") 
plot_performance(master_data,master_data$trades_opened_in_last_6_months,"trades_opened_in_last_6_months") 
plot_performance(master_data,master_data$PL_trades_opened_in_last_12_months,"PL_trades_opened_in_last_12_months") 
plot_performance(master_data,master_data$Inquiries_in_last_6_months_exc_home_auto_loans,"Inquiries_in_last_6_months_exc_home_auto_loans") 
plot_performance(master_data,master_data$Inquiries_in_last_12_months_exc_home_auto_loans,"Inquiries_in_last_12_months_exc_home_auto_loans") 
plot_performance(master_data,master_data$Has_open_home_loan,"Has_open_home_loan") 
plot_performance(master_data,master_data$Total_No_of_Trades,"Total_No_of_Trades") 
plot_performance(master_data,master_data$Has_open_auto_loan,"Has_open_auto_loan") 

##########Multivariate Analysis######

#Have two copies of data frame one for WOE and another for creating dummy variables. 

Woe_data <- master_data

eda_data <- master_data

#Lets do traditional way of model building as well as by replacing with woe values.



#### Data Preparation for traditional way.

(sum(is.na(eda_data))/nrow(eda_data))*100  #0.215% 

#As there are less number of missing values lets remove all NA 

eda_data <- drop_na(eda_data)


###dummy variables creation

factor_col <- eda_data[,c(3,4,5,7,8,9,25,28)]

factor_col<- data.frame(sapply(factor_col, function(x) factor(x)))


# creating dummy variables for factor attributes

dummies<- data.frame(sapply(factor_col,function(x) data.frame(model.matrix(~x-1,data =factor_col))[,-1]))

dummies_data<- cbind(eda_data[,c(1,2,6,10:24,26,27)],dummies)

dummies_data$Performance_Tag <- eda_data$Performance_Tag

dummies_data$Performance_Tag <- as.numeric(dummies_data$Performance_Tag)
str(dummies_data)
cor <-round(cor(dummies_data[,c(1:20,39)],use="pairwise.complete.obs"),1)
ggcorrplot(cor,lab = T,type = "lower")

cor1 <-round(cor(dummies_data[,c(21:39)],use="pairwise.complete.obs"),1)
ggcorrplot(cor1,lab = T,type = "lower")

#Credit_beareau data has corrolation with Performance_Tag. Below are few variables:
#No_of_times_90_DPD_or_worse_12_months
#No_of_times_60_DPD_or_worse_12_months
#No_of_times_30_DPD_or_worse_12_months
#Avgas_CC_Utilization_in_12_months
#trades_opened_in_last_6_months
#trades_opened_in_last_12_months 
#PL_trades_opened_in_last_12_months
#Inquiries_in_last_12_months_exc_home_auto_loans 

##########################WOE and Information Value####

#Convert categorical variables to factors.
 Woe_data[,c(3,4,5,7,8,9,25,28,29)] <- lapply(Woe_data[,c(3,4,5,7,8,9,25,28,29)], factor)
str(Woe_data)

##Lets use the package scorecard for finding Information value and woe.

infovalue <- iv(Woe_data, y = "Performance_Tag")
View(infovalue)

######Strong Predictors########
#1:              Avgas_CC_Utilization_in_12_months 3.590032e-01
#2:                trades_opened_in_last_12_months 3.094659e-01
#3:Inquiries_in_last_12_months_exc_home_auto_loans 3.018928e-01
#4:             PL_trades_opened_in_last_12_months 3.004986e-01

#####Medium Predictors
#5:                              Total_No_of_Trades 2.726837e-01
#6:            No_of_times_30_DPD_or_worse_6_months 2.445830e-01
#7:               PL_trades_opened_in_last_6_months 2.247964e-01
#8:           No_of_times_30_DPD_or_worse_12_months 2.194434e-01
#9:           No_of_times_90_DPD_or_worse_12_months 2.158957e-01
#10:            No_of_times_60_DPD_or_worse_6_months 2.115039e-01
#11:  Inquiries_in_last_6_months_exc_home_auto_loans 2.093466e-01
#12:                  trades_opened_in_last_6_months 1.930070e-01
#13:           No_of_times_60_DPD_or_worse_12_months 1.885912e-01
#14:            No_of_times_90_DPD_or_worse_6_months 1.627664e-01
#15:               No_of_months_in_current_residence 1.461112e-01

#######Weak Predictors##
#16:                             Outstanding_Balance 8.543144e-02
#17:                                          Income 6.533149e-02
#18:                 No_of_months_in_current_company 6.222427e-02
#19:                                             Age 1.755812e-02
#20:                              Has_open_home_loan 1.721557e-02
#21:                                No_of_dependents 3.409787e-03
#22:                                      Profession 2.085693e-03
#23:                              Has_open_auto_loan 1.693935e-03
#24:                               Type_of_residence 1.169867e-03
#25:                                          Gender 1.093574e-03
#26:                                       Education 7.558508e-04
#27:                                  Marital_Status 4.054766e-04

bins <- woebin(Woe_data,"Performance_Tag")

#Let us plot the WOe bins for all the variables.
plotlist <- woebin_plot(bins)
print(plotlist$Age)
print(plotlist$Gender)
print(plotlist$Marital_Status)
print(plotlist$No_of_dependents)
print(plotlist$Income)
print(plotlist$Education)
print(plotlist$Profession)
print(plotlist$Type_of_residence)
print(plotlist$No_of_months_in_current_company)
print(plotlist$No_of_times_90_DPD_or_worse_6_months)
print(plotlist$No_of_times_60_DPD_or_worse_6_months)
print(plotlist$No_of_times_30_DPD_or_worse_6_months)
print(plotlist$No_of_times_90_DPD_or_worse_12_months)
print(plotlist$No_of_times_60_DPD_or_worse_12_months)
print(plotlist$No_of_times_30_DPD_or_worse_12_months)
print(plotlist$Avgas_CC_Utilization_in_12_months)
print(plotlist$trades_opened_in_last_6_months)
print(plotlist$trades_opened_in_last_12_months)
print(plotlist$PL_trades_opened_in_last_6_months)
print(plotlist$PL_trades_opened_in_last_12_months)
print(plotlist$Inquiries_in_last_6_months_exc_home_auto_loans)
print(plotlist$Inquiries_in_last_12_months_exc_home_auto_loans)
print(plotlist$Has_open_home_loan)
print(plotlist$Outstanding_Balance)
print(plotlist$Total_No_of_Trades)
print(plotlist$Has_open_auto_loan)

######################Model Building########################

# Model with only Demograhic data
demo <- dummies_data[,c(1:5,21:36,39)]
set.seed(100)

split_indices <- sample.split(demo$Performance_Tag, SplitRatio = 0.70)

train_demo <- demo[split_indices, ]
train_demo$Performance_Tag <- as.factor(as.character(train_demo$Performance_Tag))

test_demo <- demo[!split_indices, ]
test_demo$Performance_Tag <- as.factor(as.character(test_demo$Performance_Tag))

#Lets see the class distribution

table(train_demo$Performance_Tag)

prop.table(table(train_demo$Performance_Tag))

#we have only 4% of default cases. We have to handle the class imbalance. Lets use Smote fn from ROSE Package.

train_demo_smote <- SMOTE(Performance_Tag ~ ., train_demo[,-1], perc.over = 700, perc.under=150)
str(train_demo)

table(train_demo_smote$Performance_Tag)

prop.table(table(train_demo_smote$Performance_Tag))

model1 <- glm(Performance_Tag ~ . , family = "binomial", data = train_demo_smote)

summary(model1)

sort(vif(model1),decreasing = TRUE)

model2 <- stepAIC(model1, direction = "both")

summary(model2)

sort(vif(model2),decreasing = TRUE)

#Remove No_of_months_in_current_residence

model3 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company + Gender + Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x3 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xMasters + Education.xPhd + 
                Education.xProfessional + Profession.xSE + Type_of_residence.xOthers + 
                Type_of_residence.xOwned + Type_of_residence.xRented, family = "binomial", 
              data = train_demo_smote)

summary(model3)

sort(vif(model3),decreasing = TRUE)

#Remove Type_of_residence.xRented

model4 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company + Gender + Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x3 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xMasters + Education.xPhd + 
                Education.xProfessional + Profession.xSE + Type_of_residence.xOthers + 
                Type_of_residence.xOwned , family = "binomial", 
              data = train_demo_smote)

summary(model4)
sort(vif(model4),decreasing = TRUE)

#Remove Type_of_residence.xOwned


model5 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company + Gender + Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x3 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xMasters + Education.xPhd + 
                Education.xProfessional + Profession.xSE + Type_of_residence.xOthers
                 , family = "binomial", 
              data = train_demo_smote)

summary(model5)

sort(vif(model5),decreasing = TRUE)

#Remove Gender

model6 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company +  Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x3 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xMasters + Education.xPhd + 
                Education.xProfessional + Profession.xSE + Type_of_residence.xOthers
              , family = "binomial", 
              data = train_demo_smote)

summary(model6)

sort(vif(model6),decreasing = TRUE)

#Remove Education.xProfessional

model7 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company +  Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x3 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xMasters + Education.xPhd + 
                 Profession.xSE + Type_of_residence.xOthers
              , family = "binomial", 
              data = train_demo_smote)

summary(model7)

sort(vif(model7),decreasing = TRUE)

#Remove Education.xMasters

model8 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company +  Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x3 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xPhd + 
                Profession.xSE + Type_of_residence.xOthers
              , family = "binomial", 
              data = train_demo_smote)

summary(model8)

sort(vif(model8),decreasing = TRUE)

#Remove No_of_dependents.x3

model9 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company +  Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x4 + 
                No_of_dependents.x5 + Education.xPhd + 
                Profession.xSE + Type_of_residence.xOthers
              , family = "binomial", 
              data = train_demo_smote)

summary(model9)

sort(vif(model9),decreasing = TRUE)


#Remove No_of_dependents.x5

model10 <- glm(formula = Performance_Tag ~ Income + 
                No_of_months_in_current_company +  Marital_Status + 
                No_of_dependents.x2 + No_of_dependents.x4 + 
                Education.xPhd + 
                Profession.xSE + Type_of_residence.xOthers
              , family = "binomial", 
              data = train_demo_smote)

summary(model10)

sort(vif(model10),decreasing = TRUE)

#Remove No_of_dependents.x4

model11 <- glm(formula = Performance_Tag ~ Income + 
                 No_of_months_in_current_company +  Marital_Status + 
                 No_of_dependents.x2 + 
                 Education.xPhd + 
                 Profession.xSE + Type_of_residence.xOthers
               , family = "binomial", 
               data = train_demo_smote)

summary(model11)

sort(vif(model11),decreasing = TRUE)

#Remove Education.xPhd

model12 <- glm(formula = Performance_Tag ~ Income + 
                 No_of_months_in_current_company +  Marital_Status + 
                 No_of_dependents.x2 + 
                 Profession.xSE + Type_of_residence.xOthers
               , family = "binomial", 
               data = train_demo_smote)

summary(model12)

sort(vif(model12),decreasing = TRUE)

#Remove Profession.xSE

model13 <- glm(formula = Performance_Tag ~ Income + 
                 No_of_months_in_current_company +  Marital_Status + 
                 No_of_dependents.x2 + 
                 Type_of_residence.xOthers, family = "binomial", 
               data = train_demo_smote)

summary(model13)

sort(vif(model13),decreasing = TRUE)

# All the variables are significant. Lets evaluate the model


demo_logistic <- predict(model13, newdata = test_demo[,c(-1, -22)], type = "response") 


summary(demo_logistic) 



# Find out the optimal probalility cutoff 



perform_fn <- function(cutoff) 
  
{
  
  predicted_demo <- factor(ifelse(demo_logistic >= cutoff, "1", "0"))
  
  conf <- confusionMatrix(predicted_demo, test_demo$Performance_Tag, positive = "1")
  conf
  ac  <- conf$overall[1]
  
  sens <- conf$byClass[1]
  
  spec <- conf$byClass[2]
  
  out  <- t(as.matrix(c(sens, spec, ac))) 
  
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  
  return(out)
  
}

# Creating cutoff values 


s = seq(.01,.95,length=100)

OUT = matrix(0,100,3)

for(i in 1:100)
  
{
  
  OUT[i,] = perform_fn(s[i])
  
} 




plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)

axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

lines(s,OUT[,2],col="darkgreen",lwd=2)

lines(s,OUT[,3],col=4,lwd=2)

box()

legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))



cutoff <- s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]
#s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]
#s[which(abs(OUT[,1]-OUT[,2])<0.01)] 

cutoff

# Let's choose a cutoff value of 0.437 for final model


test_demo_cutoff_default <- factor(ifelse(pred_logistic >=0.437, "1", "0"))


conf_final <- confusionMatrix(test_demo_cutoff_default, test_data$Performance_Tag, positive = "1")

conf_final

ac <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

ac
#0.60
sens
#0.64
spec
#0.598

# Above accuracy is for model with demographic data.

###########################################################################

### Logistic model with both demographic and credit information ###

full_data <- dummies_data
set.seed(100)

split_indices <- sample.split(full_data$Performance_Tag, SplitRatio = 0.70)

train_full <- full_data[split_indices, ]
train_full$Performance_Tag <- as.factor(as.character(train_demo$Performance_Tag))

test_full <- full_data[!split_indices, ]
test_full$Performance_Tag <- as.factor(as.character(test_full$Performance_Tag))

#Lets see the class distribution

table(train_full$Performance_Tag)

prop.table(table(train_full$Performance_Tag))

#we have only 4% of default cases. We have to handle the class imbalance. Lets use Smote fn from ROSE Package.

train_full_smote <- SMOTE(Performance_Tag ~ ., train_full[,-1], perc.over = 700, perc.under=150)


table(train_full_smote$Performance_Tag)

prop.table(table(train_full_smote$Performance_Tag))

model_full1 <- glm(Performance_Tag ~ . , family = "binomial", data = train_full_smote)

summary(model_full1)

sort(vif(model_full1),decreasing = TRUE)

model_full2 <- stepAIC(model_full1, direction = "both")

summary(model_full2)

sort(vif(model_full2),decreasing = TRUE)

#Remove No_of_times_30_DPD_or_worse_12_months

model_full3 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
          No_of_months_in_current_company + No_of_times_60_DPD_or_worse_6_months + 
      No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
       Avgas_CC_Utilization_in_12_months + 
      trades_opened_in_last_6_months + PL_trades_opened_in_last_6_months + 
      PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
      Inquiries_in_last_12_months_exc_home_auto_loans + Outstanding_Balance + 
      Total_No_of_Trades + Gender + Marital_Status + No_of_dependents.x2 + 
      No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
      Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
      Type_of_residence.xOwned + Type_of_residence.xRented + Has_open_home_loan + 
      Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full3)

sort(vif(model_full3),decreasing = TRUE)

#Remove trades_opened_in_last_6_months

model_full4 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + No_of_times_60_DPD_or_worse_6_months + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                     PL_trades_opened_in_last_6_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Inquiries_in_last_12_months_exc_home_auto_loans + Outstanding_Balance + 
                    Total_No_of_Trades + Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + Type_of_residence.xRented + Has_open_home_loan + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full4)

#Remove Outstanding_Balance
#Has_open_home_loan

model_full5 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + No_of_times_60_DPD_or_worse_6_months + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                    PL_trades_opened_in_last_6_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Inquiries_in_last_12_months_exc_home_auto_loans + 
                    Total_No_of_Trades + Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + Type_of_residence.xRented + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full5)

sort(vif(model_full5),decreasing = TRUE)

#Remove PL_trades_opened_in_last_6_months
model_full6 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + No_of_times_60_DPD_or_worse_6_months + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Inquiries_in_last_12_months_exc_home_auto_loans + 
                    Total_No_of_Trades + Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + Type_of_residence.xRented + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full6)

sort(vif(model_full6),decreasing = TRUE)

#Remove No_of_times_60_DPD_or_worse_6_months

model_full7 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Inquiries_in_last_12_months_exc_home_auto_loans + 
                    Total_No_of_Trades + Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + Type_of_residence.xRented + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full7)

sort(vif(model_full7),decreasing = TRUE)

#Remove Inquiries_in_last_12_months_exc_home_auto_loans

model_full8 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Total_No_of_Trades + Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + Type_of_residence.xRented + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full8)

sort(vif(model_full8),decreasing = TRUE)

#Remove Total_No_of_Trades

model_full9 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + Type_of_residence.xRented + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full9)

sort(vif(model_full9),decreasing = TRUE)

#Remove Type_of_residence.xRented

model_full10 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                    No_of_months_in_current_company + 
                    No_of_times_30_DPD_or_worse_6_months + No_of_times_90_DPD_or_worse_12_months + 
                    Avgas_CC_Utilization_in_12_months + 
                    PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                    Gender + Marital_Status + No_of_dependents.x2 + 
                    No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                    Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                    Type_of_residence.xOwned + 
                    Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full10)

sort(vif(model_full10),decreasing = TRUE)

#Remove No_of_times_90_DPD_or_worse_12_months

model_full11 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                     No_of_months_in_current_company + 
                     No_of_times_30_DPD_or_worse_6_months + 
                     Avgas_CC_Utilization_in_12_months + 
                     PL_trades_opened_in_last_12_months + Inquiries_in_last_6_months_exc_home_auto_loans + 
                     Gender + Marital_Status + No_of_dependents.x2 + 
                     No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                     Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                     Type_of_residence.xOwned + 
                     Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full11)

sort(vif(model_full11),decreasing = TRUE)

#Remove Inquiries_in_last_6_months_exc_home_auto_loans

model_full12 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                     No_of_months_in_current_company + 
                     No_of_times_30_DPD_or_worse_6_months + 
                     Avgas_CC_Utilization_in_12_months + 
                     PL_trades_opened_in_last_12_months + 
                     Gender + Marital_Status + No_of_dependents.x2 + 
                     No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                     Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                     Type_of_residence.xOwned + 
                     Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full12)

sort(vif(model_full12),decreasing = TRUE)

#Remove Type_of_residence.xOwned

model_full13 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                     No_of_months_in_current_company + 
                     No_of_times_30_DPD_or_worse_6_months + 
                     Avgas_CC_Utilization_in_12_months + 
                     PL_trades_opened_in_last_12_months + 
                     Gender + Marital_Status + No_of_dependents.x2 + 
                     No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                     Education.xPhd + Profession.xSE_PROF + Type_of_residence.xOthers + 
                     Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full13)

sort(vif(model_full13),decreasing = TRUE)

#Remove Profession.xSE_PROF

model_full14 <-glm(formula = Performance_Tag ~ Income + No_of_months_in_current_residence + 
                     No_of_months_in_current_company + 
                     No_of_times_30_DPD_or_worse_6_months + 
                     Avgas_CC_Utilization_in_12_months + 
                     PL_trades_opened_in_last_12_months + 
                     Gender + Marital_Status + No_of_dependents.x2 + 
                     No_of_dependents.x3 + No_of_dependents.x4 + No_of_dependents.x5 + 
                     Education.xPhd + Type_of_residence.xOthers + 
                     Has_open_auto_loan, family = "binomial", data = train_full_smote)

summary(model_full14)

sort(vif(model_full14),decreasing = TRUE)

#All the variables are significant

logistic <- predict(model_full14, newdata = test_full[,c(-1, -39)], type = "response") 


summary(logistic) 



# Find out the optimal probalility cutoff 



perform_fn <- function(cutoff) 
  
{
  
  predicted_full <- factor(ifelse(logistic >= cutoff, "1", "0"))
  
  conf <- confusionMatrix(predicted_full, test_full$Performance_Tag, positive = "1")
  conf
  ac  <- conf$overall[1]
  
  sens <- conf$byClass[1]
  
  spec <- conf$byClass[2]
  
  out  <- t(as.matrix(c(sens, spec, ac))) 
  
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  
  return(out)
  
}

# Creating cutoff values 


s = seq(.01,.95,length=100)

OUT = matrix(0,100,3)

for(i in 1:100)
  
{
  
  OUT[i,] = perform_fn(s[i])
  
} 




plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)

axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

lines(s,OUT[,2],col="darkgreen",lwd=2)

lines(s,OUT[,3],col=4,lwd=2)

box()

legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))



cutoff <- s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]
#s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]
#s[which(abs(OUT[,1]-OUT[,2])<0.01)] 

cutoff

# Let's choose a cutoff value of 0.44 for final model


test_full_cutoff_default <- factor(ifelse(logistic >=0.44, "1", "0"))


conf_final <- confusionMatrix(test_full_cutoff_default, test_full$Performance_Tag, positive = "1")

conf_final

ac <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

ac
#0.61
sens
#0.63
spec
#0.61

#Accuracy is around 63%

##################MOdels with WOE values##################

#Replacing actual values with WOE values.

dt_woe <- woebin_ply(Woe_data,bins)

bins_df = data.table::rbindlist(bins)
View(bins_df)

##Removing Application_Id_woe and adding Application_Id
dt_woe <-dt_woe[,-2]
dt_woe$Application_ID <- Woe_data$Application_ID

##Adding Performance_Tag to the last
dt_woe <- dt_woe %>% select(-Performance_Tag,Performance_Tag)
dt_woe$Performance_Tag <- as.factor(as.character(dt_woe$Performance_Tag))

############Model building#############

set.seed(100)

split_indices <- sample.split(dt_woe$Performance_Tag, SplitRatio = 0.70)

train_data <- dt_woe[split_indices, ]
train_data$Performance_Tag <- as.factor(as.character(train_data$Performance_Tag))

test_data <- dt_woe[!split_indices, ]
test_data$Performance_Tag <- as.factor(as.character(test_data$Performance_Tag))

#Lets see the class distribution

table(train_data$Performance_Tag)

prop.table(table(train_data$Performance_Tag))

# We have only 4% of data for default cases are available in the given data. So there is a clear class imbalance seen.
# Lets do sampling to avoid this class imbalance


#Oversampling will result in more samples and under sampling will result in less samples.
#So lets use SMOTE to overcome the class imbalance.


#train_data_smote <- SMOTE(Performance_Tag ~ ., train_data, perc.over = 200, perc.under=100)

train_data_smote <- SMOTE(Performance_Tag ~., train_data, perc.over = 700, perc.under=120)

table(train_data_smote$Performance_Tag)

prop.table(table(train_data_smote$Performance_Tag))
 
## Now the class distribution looks good.

model_1 <- glm(Performance_Tag ~., family = "binomial", data = train_data_smote)

summary(model_1)

sort(vif(model_1),decreasing = TRUE)


model_2 <- stepAIC(model_1, direction = "both")

summary(model_2)

sort(vif(model_2),decreasing = TRUE)

#Remove No_of_times_60_DPD_or_worse_6_months_woe

model_3 <- glm(formula = Performance_Tag ~ Age_woe + Gender_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + Education_woe + Profession_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                  No_of_times_90_DPD_or_worse_12_months_woe + 
                 No_of_times_60_DPD_or_worse_12_months_woe + No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 trades_opened_in_last_12_months_woe + PL_trades_opened_in_last_6_months_woe + 
                Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_3)

sort(vif(model_3),decreasing = TRUE)

# Remove No_of_times_60_DPD_or_worse_12_months_woe

model_4 <- glm(formula = Performance_Tag ~ Age_woe + Gender_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + Education_woe + Profession_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_90_DPD_or_worse_12_months_woe + No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 trades_opened_in_last_12_months_woe + PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_4)

sort(vif(model_4),decreasing = TRUE)

# Remove trades_opened_in_last_12_months_woe

model_5 <- glm(formula = Performance_Tag ~ Age_woe + Gender_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + Education_woe + Profession_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_90_DPD_or_worse_12_months_woe + No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_5)

sort(vif(model_5),decreasing = TRUE)

# Remove Gender_woe

model_6 <- glm(formula = Performance_Tag ~ Age_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + Education_woe + Profession_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_90_DPD_or_worse_12_months_woe + No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_6)

sort(vif(model_6),decreasing = TRUE)

# Remove No_of_times_90_DPD_or_worse_12_months_woe

model_7 <- glm(formula = Performance_Tag ~ Age_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + Education_woe + Profession_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_7)

sort(vif(model_7),decreasing = TRUE)

# Remove Education_woe

model_8 <- glm(formula = Performance_Tag ~ Age_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + Profession_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_8)

sort(vif(model_8),decreasing = TRUE)

# Remove Profession_woe

model_9 <- glm(formula = Performance_Tag ~ Age_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                 Has_open_home_loan_woe + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_9)

sort(vif(model_9),decreasing = TRUE)

# Remove Has_open_home_loan_woe

model_10 <- glm(formula = Performance_Tag ~ Age_woe + Marital_Status_woe + 
                 No_of_dependents_woe + Income_woe + 
                 Type_of_residence_woe + No_of_months_in_current_residence_woe + 
                 No_of_months_in_current_company_woe +
                 No_of_times_30_DPD_or_worse_12_months_woe + 
                 Avgas_CC_Utilization_in_12_months_woe +
                 PL_trades_opened_in_last_6_months_woe + 
                 Inquiries_in_last_6_months_exc_home_auto_loans_woe + 
                  + Outstanding_Balance_woe + Has_open_auto_loan_woe, 
               family = "binomial", data = train_data_smote)

summary(model_10)

sort(vif(model_10),decreasing = TRUE)

# All the variables are significant


logistic_model <- model_10

#Model Evaluation



#predicted probabilities of default for test data

pred_logistic <- predict(logistic_model, newdata = test_data[, c(-28,-29)], type = "response") 

summary(pred_logistic) 


# Find out the optimal probalility cutoff 


perform_fn <- function(cutoff) 
  
{
  
  predicted_default <- factor(ifelse(pred_logistic >= cutoff, "1", "0"))
  
  conf <- confusionMatrix(predicted_default, test_data$Performance_Tag, positive = "1")
  
  ac  <- conf$overall[1]
  
  sens <- conf$byClass[1]
  
  spec <- conf$byClass[2]
  
  out  <- t(as.matrix(c(sens, spec, ac))) 
  
  colnames(out) <- c("sensitivity", "specificity", "accuracy")
  
  return(out)
  
}

# Creating cutoff values 


s = seq(.01,.95,length=100)

OUT = matrix(0,100,3)

for(i in 1:100)
  
{
  
  OUT[i,] = perform_fn(s[i])
  
} 




plot(s, OUT[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)

axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

lines(s,OUT[,2],col="darkgreen",lwd=2)

lines(s,OUT[,3],col=4,lwd=2)

box()

legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))





cutoff <- s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]
  #s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]
 #s[which(abs(OUT[,1]-OUT[,2])<0.01)] 



cutoff

# Let's choose a cutoff value of 0.503 for final model



test_pred_cutoff_default <- factor(ifelse(pred_logistic >=0.503, "1", "0"))


conf_final <- confusionMatrix(test_pred_cutoff_default, test_data$Performance_Tag, positive = "1")

conf_final

ac <- conf_final$overall[1]

sens <- conf_final$byClass[1]

spec <- conf_final$byClass[2]

ac
#0.613
sens
#0.630
spec
#0.612



########Decision Tree

library(rpart)
library(rpart.plot)
Dectree_1 <- rpart(Performance_Tag ~ ., data= train_data_smote[,-28],method = "class",
                   control = rpart.control(cp = .000001,minsplit = 1000))
prp(Dectree_1, roundint = FALSE)

summary(Dectree_1)
printcp(Dectree_1)
plotcp(Dectree_1)
# make predictions on the test set

pred_tree1 <- predict(Dectree_1, test_data, type = "class")

# evaluate the results

confusionMatrix(test_data$Performance_Tag, pred_tree1, positive = "1")

## Acc - 84%  Sen - 5% and Spec - 95%
#sensitivity is very low.

Dectree_2 <- rpart(Performance_Tag ~ ., data= train_data_smote[,-28],method = "class",
                   control = rpart.control(cp = 0.00002,maxdepth= 20,minbucket = 100,minsplit = 100))
prp(Dectree_2, roundint = FALSE)
rpart.plot(Dectree_2)
summary(Dectree_2)
printcp(Dectree_2)
plotcp(Dectree_2)

pred_tree2 <- predict(Dectree_2, test_data, type = "class")

# evaluate the results

confusionMatrix(test_data$Performance_Tag, pred_tree2, positive = "1")

## Acc - 89%  Sen - 6% and Spec - 96%
#sensitivity is very low.

Dectree3 <-prune(Dectree_2, cp =0.00001)
#lets prune the tree
printcp(Dectree3)


# make predictions on the test set

pred_tree3 <- predict(Dectree3, test_data, type = "class")

# evaluate the results

confusionMatrix(test_data$Performance_Tag, pred_tree3, positive = "1")

#Accuracy is 90%. But still sensitivity is too low


Dectree_4  <- rpart(Performance_Tag ~., data = train_data_smote[,-28],method = "class", control = rpart.control(minsplit = 1,minbucket = 1, cp = 0.01))       
prp(Dectree_4, roundint = FALSE)

# make predictions on the test set

Dectree.predict <- predict(Dectree_4,test_data[,-28], type = "class")

# evaluate the results

confusionMatrix(test_data$Performance_Tag, Dectree.predict, positive = "1")

#Acc - 88% Sens - 7%  spec - 96%

Dectree_5  <- rpart(Performance_Tag ~., data = train_data_smote[,-28],method = "class", control = rpart.control(minsplit = 20,minbucket = 20, cp = 0.01))       
prp(Dectree_5, roundint = FALSE)

# make predictions on the test set

Dectree.predict <- predict(Dectree_5,test_data[,-28], type = "class")

# evaluate the results

confusionMatrix(test_data$Performance_Tag, Dectree.predict, positive = "1")
#Acc - 88% Sen - 7%   spec -96%

#Hence we can conclude that Decision tree is overfitiing and not giving best result.
#So lets build a Random Forest.

############## Random Forest ###########

train_rf <- randomForest(Performance_Tag ~., data = train_data_smote[,-28], proximity = F, do.trace = T, mtry = 5)



# Predict response on test data


pred_rf <- predict(train_rf, test_data[, -c(28,29)], type = "prob")

# Cutoff for randomforest


perform_rf <- function(cutoff) 
  
{
  
  predicted_rf <- as.factor(ifelse(pred_rf[, 2] >= cutoff, "1", "0"))
  
  conf <- confusionMatrix(predicted_rf, test_data$Performance_Tag, positive = "1")
  
  ac <- conf$overall[1]
  
  sens <- conf$byClass[1]
  
  spec <- conf$byClass[2]
  
  OUT_rf <- t(as.matrix(c(sens, spec, ac))) 
  
  colnames(OUT_rf) <- c("sensitivity", "specificity", "accuracy")
  
  return(OUT_rf)
  
}



summary(rf_pred[,2])



s = seq(.00,.95,length=100)



OUT_rf = matrix(0,100,3)



# calculate the sens, spec and acc for different cutoff values



for(i in 1:100)
  
{
  
  OUT_rf[i,] = perform_rf(s[i])
  
} 



# plotting cutoffs



plot(s, OUT_rf[,1],xlab="Cutoff",ylab="Value",cex.lab=1.5,cex.axis=1.5,ylim=c(0,1),type="l",lwd=2,axes=FALSE,col=2)

axis(1,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

axis(2,seq(0,1,length=5),seq(0,1,length=5),cex.lab=1.5)

lines(s,OUT_rf[,2],col="darkgreen",lwd=2)

lines(s,OUT_rf[,3],col=4,lwd=2)

box()



legend(0,.50,col=c(2,"darkgreen",4,"darkred"),lwd=c(2,2,2,2),c("Sensitivity","Specificity","Accuracy"))



min(abs(OUT_rf[,1]-OUT_rf[,2]))



cutoff_rf <- s[which(abs(OUT[,1]-OUT[,2])==min(abs(OUT[,1]-OUT[,2])))]

cutoff_rf



# The plot shows that cutoff value of around 15%  sensitivity and accuracy are near.



predicted_test <- factor(ifelse(pred_rf[, 2] >= 0.153, "1", "0"))



conf <- confusionMatrix(predicted_test, test_data$Performance_Tag, positive = "1")


conf



# Sensitivity 61%

conf$byClass[1]



# Specificity 59%

conf$byClass[2]


# Accuracy  59.6%

conf$overall[1]

## The accuracy is similar to logistic regression but less than logistic regression.


###################XGboost###########

library(xgboost)

#library(magrittr) 

library(Matrix)
library(data.table)
library(mlr)

setDT(train_data_smote)
setDT(test_data)

set.seed(100)

train_label <- train_data_smote$Performance_Tag
train_label <- as.numeric(train_label)-1



train_matrix <- xgb.DMatrix(data = as.matrix(train_data_smote[,-29]), label = train_label)

test_label <- test_data$Performance_Tag
test_label <- as.numeric(test_label)-1

test_matrix <- xgb.DMatrix(data = as.matrix(test_data[,-29]), label = test_label)

rej_label <- rej_woe$Performance_Tag
#rej_label <- as.numeric(rej_label)-1

rej_matrix <- xgb.DMatrix(data = as.matrix(rej_woe[,-29]), label = rej_label)

param <- list(booster = "gbtree",objective = "binary:logistic", eta =0.3,
              gamma = 0, max_depth = 6, min_child_weight = 1, subsample = 1, colsample_bytree= 1)

xgbcv<- xgb.cv(params = param, data =train_matrix, nrounds = 100, nfold = 5, showsd = T,
               print_every_n = 10, early_stopping_round = 20, maximize = F)
  
min(xgbcv$evaluation_log$test_error_mean)#0.062
#Accuracy
acc_1 <-100-min(xgbcv$evaluation_log$test_error_mean)*100
acc_1 #we have achieved 93% Accuracy

#####Model Training

xgb1 <- xgb.train(params = param, data = train_matrix, nrounds = 43, 
                  watchlist = list(val=test_matrix, train = train_matrix ),
                  print_every_n = 10, early_stopping_round = 10,maximize = F, eval_metric = 'error')
xgb1
xgbpred <-predict(xgb1,test_matrix)
xgb_tag <-ifelse(xgbpred > 0.11,1,0) # Manually tried different values

confusionMatrix(as.factor(xgb_tag),as.factor(test_data$Performance_Tag),positive = "1")


#Accuracy : 59.5%
#Sensitivity: 59.7%
#Specificity: 59.5%

#Lets predict on rejected records.
rejpred <-predict(xgb1,rej_matrix)

rej_tag <-ifelse(rejpred > 0.11,1,0)
sum(rej_tag)/1425 # We are getting only 93% accuracy in rejected records.
# Calculate feature importance


imp <-xgb.importance(feature_names = colnames(train_data_smote),model = xgb1)
xgb.plot.importance(importance_matrix = imp[1:20])

print(imp)


traintask <- makeClassifTask(data = data.frame(train_data_smote),target = "Performance_Tag")
testtask <- makeClassifTask(data = data.frame(test_data), target = "Performance_Tag")

#create learner


lrn <- makeLearner("classif.xgboost", predict.type = "response")
lrn$par.vals<- list(objective="binary:logistic", eval_metric="error",nrounds = 100L, eta = 0.1)

#set parameter

params <- makeParamSet(makeDiscreteLearnerParam("booster",values = c("gbtree","gblinear")),
                       makeIntegerParam("max_depth",lower = 3L,upper = 10L),
                       makeNumericParam("min_child_weight",lower = 1L,upper = 10L), 
                       makeNumericParam("subsample",lower = 0.5,upper = 1), makeNumericParam("colsample_bytree",lower = 0.5,upper = 1))

#set resampling strategy
rdesc <- makeResampleDesc("CV",stratify = T,iters=5L)

#search strategy
ctrl <- makeTuneControlRandom(maxit = 10L)


#set parallel backend
library(parallel)
library(parallelMap) 
parallelStartSocket(cpus = detectCores())

#parameter tuning
mytune <- tuneParams(learner = lrn, task = traintask, resampling = rdesc, measures= list(acc), 
                     par.set = params, control = ctrl, show.info = T)
mytune$y # Acc88%

#measures =list(auc),

lrn_tune <- setHyperPars(lrn,par.vals = mytune$x)

#traning model

xg_model <- train (learner = lrn_tune,task= traintask)
xg_pred <- predict(xg_model,testtask)

confusionMatrix(xg_pred$data$response,xg_pred$data$truth,positive = "1")


## We are acheiving accuracy of 95% though our sensitivity is too low. So let go with the
#model xgbpred with cutof - 0.11

#Accuracy : 59.5%
#Sensitivity: 59.7%
#Specificity: 59.5%

#This accuracy is less compared to logistic regression model.So lets take the logistic regression model
# built with WOE values to predict rejected records and building Application score card


#################SVM Model#######################

# SVM performance will be an issue with large data so we sample the training data.Lets take records less than 5000.
set.seed(100)
sample <- createDataPartition(train_data_smote$Performance_Tag,p=0.07,list = F) # extracting subset of 2362 samples
trainsvm <- train_data_smote[sample, ]

model1_linear <- ksvm(Performance_Tag ~ ., data = trainsvm, scaled = TRUE, kernel = "vanilladot", C = 1)
print(model1_linear) 

eval1_linear <- predict(model1_linear, newdata = test_data, type = "response")
CF1 <-confusionMatrix(eval1_linear, test_data$Performance_Tag) 
CF1
###Accuracy - 56.5, sens - 55.4, spec - 69.So lets build linear kernel with C=10

model2_linear <- ksvm(Performance_Tag ~ ., data = trainsvm, scaled = TRUE, kernel = "vanilladot", C = 10)
print(model2_linear) 

eval2_linear <- predict(model2_linear, newdata = test_data, type = "response")
CF2 <-confusionMatrix(eval2_linear, test_data$Performance_Tag) 
CF2

## We are getting almost same accuracy as above model.


## Using cross validation to optimise C

grid_linear <- expand.grid(C= c(0.01, 0.1 ,1 ,10 ,100)) # defining range of C

fit.linear <- caret::train(Performance_Tag ~ ., data = trainsvm, metric = "Accuracy", method = "svmLinear", scale = T,
                    tuneGrid = grid_linear, preProcess = NULL,
                    trControl = trainControl(method = "cv", number = 5))


# printing results of 5 cross validation
print(fit.linear) 
plot(fit.linear)

#Best accuracy is when c - 0.1

eval_svmLinear<- predict(fit.linear, test_data)
confusionMatrix(eval_svmLinear, test_data$Performance_Tag)

#Accuracy = 57, Sensitivity = 56 and Specificity = 68

## Radial kernel using default parameters

model1_rbf <- ksvm(Performance_Tag ~ ., data = trainsvm, scaled = TRUE, kernel = "rbfdot", C = 1, kpar = "automatic")
print(model1_rbf) 

eval1_rbf <- predict(model1_rbf, newdata = test_data, type = "response")
CF4 <-confusionMatrix(eval1_rbf, test_data$Performance_Tag) 
CF4

#Accuracy = 63%, Sensitivity = 63% and Specificity = 58%

# Using cross validation to optimise C and sigma

# defining ranges of C and sigma
grid_rbf = expand.grid(C= c(0.01, 0.1, 1, 5, 10), sigma = c(0.001, 0.01, 0.1, 1, 5)) 

# Using only 2 folds to optimise run time
fit.rbf <- caret::train(Performance_Tag ~ ., data = trainsvm, metric = "Accuracy", method = "svmRadial",tuneGrid = grid_rbf,
                 trControl = trainControl(method = "cv", number = 2), preProcess = NULL, scale = T)

# printing results of 2 cross validation
print(fit.rbf) 
plot(fit.rbf)

#The final values used for the model were sigma = 0.1 and C = 1.

eval_cv_rbf <- predict(fit.rbf, newdata = test_data)
confusionMatrix(eval_cv_rbf, test_data$Performance_Tag)

#Accuracy = 69.4%, Sensitivity = 70.5% and Specificity = 45.6%

#--------------------------------------------- Polynomial Kernel ----------------------------------------------#

## Polynomial kernel with degree 2, default scale and offset
model1_poly <- ksvm(Performance_Tag ~ ., data = trainsvm, kernel = "polydot", scaled = TRUE, C = 1, 
                    kpar = list(degree = 2, scale = 1, offset = 1))
print(model1_poly)

eval1_poly <- predict(model1_poly, newdata = test_data)
confusionMatrix(eval1_poly, test_data$Performance_Tag)

#Accuracy = 69.7%, Sensitivity = 71% and Specificity = 40%

library(doParallel)
no_cores <- detectCores()-1
registerDoParallel(cores=no_cores)

trainControl<-trainControl(method = "cv", number = 5, returnResamp = "all")

fit.svm_poly  <- caret::train(Performance_Tag ~ ., data = trainsvm, method = "svmPoly", trControl = trainControl, preProc = c("center", "scale"))
print(fit.svm_poly)
plot(fit.svm_poly)

#The final values used for the model were degree = 2, scale = 0.1 and C = 1.

# Predicting the model results 
Eval_fit.svm_poly<- predict(fit.svm_poly, test_data)
#confusion matrix - RBF Kernel
confusionMatrix(Eval_fit.svm_poly,test_data$Performance_Tag)

##########Predicting Performance_Tag for Rejected records#####

Rejected_data[c(426:1425),29] <- 0
Rejected_data[c(1:425),29] <- 1
rej_woe <- woebin_ply(Rejected_data,bins) # Replacing with WOE Value

##Removing Application_Id_woe and adding Application_Id
rej_woe <-rej_woe[,-2]
rej_woe$Application_ID <- Rejected_data$Application_ID

##Adding Performance_Tag to the last
rej_woe <- rej_woe %>% select(-Performance_Tag,Performance_Tag)
rej_woe$Performance_Tag <- as.factor(as.character(rej_woe$Performance_Tag))
predd <- predict(logistic_model, newdata = rej_woe[, c(-28,-29)], type = "response") 

rej_woe$Performance_Tag <- factor(ifelse(predd >=0.503, "1", "0"))

sum(as.numeric(as.character(rej_woe$Performance_Tag)))/1425 * 100
## 97.75% are predicted as defaulters. So it is evident loan is not approved as they are high risk customers.

############Building Application scorecard#########

#bins
pred1 <- predict(logistic_model, newdata = dt_woe[, c(-28,-29)], type = "response") 
#scard <- scorecard(bins,logistic_model, points0 = 400, odds0 = 19/1, pdo = 20)
#Woe_data$score <- scorecard_ply(Woe_data,scard)
#ordered_by_score<-Woe_data[order(Woe_data$score,decreasing = TRUE)]


odds <- (1-pred1)/pred1
log_odds <- log(odds)

Score <- 400 - (20/log(2)) * (log(10) - log_odds)

Approved_data <- cbind(Woe_data,Score)
Approved_data$Default_Predicted <- factor(ifelse(pred1 >=0.503, "Yes", "No"))
#cutoff value 0.503

cut_off.app_score <- 400 - (20/log(2)) * (log(10) - log((1-0.503)/0.503))

cut_off.app_score #333.22

#Application Score more than 333.22 should be approved. And less than 333.22 should be rejected.

summary(Approved_data$Score)

ggplot(Approved_data,aes(Score))+geom_histogram()


Approved_data$status <- ifelse(Approved_data$Score >= 333.22 ,"Approve","Reject")

ggplot(Approved_data, aes(x = factor(status),y = round(Score,0), fill = factor(status)))+geom_boxplot()


############################ Calculating Application Score in Rejected records ####################################



#odd
odds_rej <-(1-predd)/predd
log_odds_rej <- log(odds_rej)


rej_Score <- 400 - (20/log(2)) * (log(10) - log_odds_rej)
Rej_data <- cbind(Rejected_data,rej_Score)
Rej_data$Default_Predicted <- factor(ifelse(predd >=0.503, "Yes", "No"))

summary(Rej_data$rej_Score)


#Calculating cut-off application score



# As per our logistic regression module, our cut-off probability of being default is 0.503 


cut_off.app_score <- 400 - (20/log(2)) * (log(10) - log((1-0.503)/0.503))

cut_off.app_score #333.22

#Application Score more than 333.22 should be approved. And less than 333.22 should be rejected.


ggplot(Rej_data,aes(rej_Score))+geom_histogram()


Rej_data$status <- ifelse(Rej_data$rej_Score >= 333.22 ,"Approve","Reject")


ggplot(Rej_data, aes(x = status,y = round(rej_Score,0), fill = factor(status)))+geom_boxplot()


###########################

#---------------------------------------------------------    

# Lets Create a new dataframe with "predicted status" and "Actual Status" for both Approved and Rejected customers.

Default_Actual <- ifelse(Approved_data$Performance_Tag == 1,"Yes" ,"No")

Actual_pred <- cbind(Approved_data[, c("Application_ID","Outstanding_Balance","Score" ,"Performance_Tag","Default_Predicted","status")],Default_Actual)
Actual_pred$Actual_status <- "Approve" 
Actual_pred$Performance_Tag <- factor(Actual_pred$Performance_Tag)
Actual_pred$Default_Actual <-factor(Actual_pred$Default_Actual)
Actual_pred$Default_Predicted <-factor(Actual_pred$Default_Predicted)


summary(Actual_pred$Default_Actual)
summary(Actual_pred$Default_Predicted)


Default_rate <- table(Actual_pred$Default_Actual)[2]/(table(Actual_pred$Default_Actual)[1] + table(Actual_pred$Default_Actual)[2])
Default_rate
# sorting the probabilities in decreasing order 
Actual_pred <- Actual_pred[order(Actual_pred$Score, decreasing = T), ]


# plotting the lift chart

lift <- function(labels , Score, groups=10) {
  
  if(is.factor(labels)) labels  <- as.integer(as.character(labels ))
  if(is.factor(Score)) Score <- as.integer(as.character(Score))
  helper = data.frame(cbind(labels , Score))
  helper[,"bucket"] = ntile(-helper[,"Score"], groups)
  gaintable = helper %>% group_by(bucket)  %>%
    summarise_at(vars(labels ), funs(total = n(),
                                     totaldef=sum(., na.rm = TRUE))) %>%
    mutate(Cumdef = cumsum(totaldef),
           Gain=Cumdef/sum(totaldef)*100,
           Cumlift=Gain/(bucket*(100/groups)),
           prospect_total = cumsum(total))
  return(gaintable)
}

# Create a Table of cumulative gain and lift 

LG = lift(Actual_pred$Performance_Tag, -Actual_pred$Score, groups = 10) # We need to capture the bad customer at top of decile

View(LG)

# From the LG chart we can understand that 75% 
#of the Defaulters are covered in the 5th Decile.

decile_5 <-subset(LG,bucket <= 5)
sum(decile_5$total)

##From 34798 Applicants we are able to predict 2204 defaulters (75%) out of 2939 total defaulters

# Gain Chart 

plot(LG$bucket,LG$Gain,col="red",type="l",main="Gain Chart",xlab="% of Total Applicants",ylab = "% of Defaulters")

# Lift Chart 

a = plot(LG$bucket,LG$Cumlift,col="blue",type="l",main="Lift Chart1",xlab="% of Total Applicants",ylab = "Lift(Ratio of Defaulters with and without model)")

# Lift Chart based on Prospects count
b =plot(LG$prospect_total,LG$Cumlift,col="red",type="l",main="Lift Chart2",xlab="Total Applicants",ylab = " Lift(Ratio of Defaulters with and without model)")

View(LG)


# The Cumulative Lift of 1.5 for top 5 deciles,
# means that when selecting 50% of the records based on the model, 
# one can expect 1.5 times the total number of targets (events) found by randomly 
# aroung 75% of defaulters can be captured from 50% of total Applicants.

### Analyzing the Charts: Cumulative gains and lift charts are a graphical 
# representation of the advantage of using a predictive model to choose which 
# Applicants to Reject. The lift chart shows how much more likely we are to find
# defaulters than if we aprrove loan without model. For example,
# by taking only 10% of Applicants based on the predictive model we will reach 
# 2 times as many defaulters as if we use no model.


#################### Financial Benefits###########################



current_approval_rate <-(nrow(Approved_data)/(nrow(Approved_data)+ nrow(Rej_data))) *100

current_approval_rate 

# current approval rate : 98%(97.99%)


default_users_outstanding <- Approved_data$Outstanding_Balance[which(Approved_data$Performance_Tag==1)]


current_credit_loss<- sum(default_users_outstanding)

current_credit_loss #3704984230


sum(ifelse(Approved_data$status=="Approve",1,0))
sum(ifelse(Rej_data$status=="Approve",1,0))

######Model bases values####

apprv <-sum(ifelse(Approved_data$status=="Approve",1,0)) +sum(ifelse(Rej_data$status=="Approve",1,0))
   
tt <- (nrow(Approved_data)+ nrow(Rej_data))

Model_approval_rate <- apprv/tt * 100 

Model_approval_rate ## 59%

#The approval rate as per our model is very low which cause business loss due to not approving right customer.
#So lets set the approval rate above 70% by changing the Scorecard cut off value from 333.22

apprv1 <-sum(ifelse(Approved_data$Score<=323,0,1)) +sum(ifelse(Rej_data$Score<=323,0,1))

New_approval_rate <- apprv1/tt * 100 

New_approval_rate #75%

## So based on our analysis lets suggest to approve all the applicants whose scorecard is above 323. By this Business loss is reduced.

fin_pred <- Actual_pred
fin_pred$Default_Predicted <- ifelse(fin_pred$Score<=323,"Yes","No")


fin_pred <- fin_pred[order(fin_pred$Score, decreasing = T), ]
View(fin_pred) # Final Approval Score

Loss1 <- filter(fin_pred,Performance_Tag ==1  & Default_Predicted== "Yes")
Loss_avoided <-sum(Loss1$Outstanding_Balance)
Loss_avoided #1491330642

Loss2 <- filter(fin_pred,Performance_Tag ==1  & Default_Predicted== "No")
Loss_missed <-sum(Loss2$Outstanding_Balance)
Loss_missed #2213653588

Precent_loss_prv <-Loss_avoided/current_credit_loss *100 
Precent_loss_prv # 40.25% loss is avoided
